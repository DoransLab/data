import os
import pandas as pd

wk_dir = os.path.abspath('..')
#%% Read in the data and pre-processing
# Columns to read 
player_vars_to_keep = ['matchId',
 'participantId',
 'teamId',
 'championId']

kill_vars_to_keep = ['matchId',
 'tEvent',
 'killerId',
 'victimId'
 ]


player = pd.read_csv(wk_dir + '/Data/match_player.csv', usecols = player_vars_to_keep)
kill = pd.read_csv(wk_dir + '/Data/match_kills.csv', usecols = kill_vars_to_keep)
id_table = pd.read_csv(wk_dir + '/Data/id_table.csv')
#%% champion Id to name


#%% Task 2



#%% Task 3
