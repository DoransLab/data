## Import statements

# import the pandas package as pd
import pandas as pd
# import operating system package
import os

wk_dir = os.path.abspath('..')
df = pd.read_csv(wk_dir+'/Data/match_player_basic.csv')

#%% Start tasks below