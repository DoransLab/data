import pandas as pd
import os

wk_dir = os.path.abspath('..')
df = pd.read_csv(wk_dir+'/Data/match_player_basic.csv')

#%% Task 2
df1 = df.groupby(by = []).agg({})
#...

#%% Task 3
df2 = df.groupby(by = []).agg({'goldEarned': 'sum'})
#...

#%% Task 4
df3 = df.groupby(by = []).agg({})
#...


#%% Task 5


