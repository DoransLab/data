#%% Import Statements and read data
import os
import pandas as pd

wk_dir = os.path.abspath('..')
id_table = pd.read_csv(wk_dir + '/Data/id_table.csv')
df = pd.read_csv(wk_dir + '/Data/match_player.csv')

#%% Examples
df = df.merge(id_table, on = 'championId', how = 'left')
df = df.drop('championId', axis = 1)
# Reorder the columns
cols = df.columns.tolist()
cols = cols[-1:] + cols[:-1]
df = df[cols]
# Rename one column
df = df.rename({'name': 'champion'}, axis = 1)