import pandas as pd
import os
import numpy as np

#%% Program set up and function definition
# Define a custom my_range_function which calculates the range for a given list
# It's a good practice to give the function definition before using it
def my_range_function(my_list):
    return np.max(my_list)-np.mean(my_list)
    

# This finds the file path of the parent working directory and stores it in wk_dir
wk_dir = os.path.abspath('..')

# Reads the match_player.csv and stores it in a DataFrame
df1 = pd.read_csv(wk_dir+'/Data/match_player_basic.csv')


#%% Section 1: Example in the introduction part

# Select the five columns to get table A
tableA = df1[['matchId','participantId','teamId','kills','deaths']]
# Group by match ID, team ID and sum the kills and deaths together
match_team_table = tableA.groupby(by=['matchId','teamId']).agg({'kills':'sum',
                          'deaths':'sum'}).reset_index()
# The second groupby-aggregate method to get the match-level table
match_table = match_team_table.groupby(by=['matchId']).agg({'kills':'sum',
                                      'deaths':'sum'})

#%% Section 2: groupby-aggregate examples

# Select the three columns to get table 1
table1 = df1[['matchId','teamId','wardsPlaced']]
# Group by match ID, team ID and get the average wards placed
df2=table1.groupby(by=['matchId','teamId']).agg('mean').reset_index()

# Form table 3
table3=df1[['matchId','teamId','wardsPlaced','wardsKilled']]
# Groupby-aggregate step
df3=table3.groupby(by=['matchId','teamId']).agg({'wardsPlaced':'mean',
                  'wardsKilled':'max'}).reset_index()

    
# Different aggregation functions examples
# The first example
df4=table3.groupby(by=['matchId','teamId']).agg({'wardsPlaced':'mean',
                  'wardsKilled':np.max}).reset_index()

# The second example
df5=table3.groupby(by=['matchId','teamId']).agg({'wardsPlaced':['mean','max'],
                  'wardsKilled':['mean',np.max,my_range_function]})

#%% Section 3: Indexes examples
    
# Table 1 example without reset_index()
df2_index=table1.groupby(by=['matchId','teamId']).agg('mean')

# Access one value in the table
avg_ward=df2_index.loc[(3362126392,100),'wardsPlaced']
print('The average wards placed for the selected game is: ',avg_ward)
