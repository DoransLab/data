import pandas as pd
import os
import matplotlib.pyplot as plt

wk_dir = os.path.abspath('..')
df = pd.read_csv(wk_dir + '/Data/match_player.csv')
df1 = pd.read_csv(wk_dir + '/Data/id_table.csv')
df = df.merge(df1, how = 'left', on = 'championId')
df = df.drop('championId', axis = 1)

cols = df.columns.tolist()
cols = cols[0:1] + cols[-1:] + cols[1:-1]
df = df[cols]

df = df.rename({'name': 'champion'}, axis = 1)

#%% Reshaping data example
df1 = df.groupby(['matchDate', 'champion']).agg({'champion': 'count'})
df1.columns = ['count']
df1 = df1.reset_index()
df1 = df1[(df1['champion'] == 'Draven') | (df1['champion'] == 'Lucian')]
result = df1.pivot(index = 'matchDate', columns = 'champion', values = 'count')
result = result.reset_index()
df1 = result.melt(id_vars = ['matchDate'])
''' df1 is the original table, and result is the resulting table after pivot
    Print out these tables in IPython console for comparison '''

#%% Visualizing data example
date = ['10-01','10-02','10-03','10-04',
        '10-05','10-06','10-07','10-08','10-09']
draven = [150,178,189,214,229,247,257,298,312]
lucian = [422,401,374,319,270,247,198,123,111]
gold = [11741,11572,11259,11868,11440,11489,11383,11359,11324]

d = {'date': date, 'DravenFrequency': draven, 'LucianFrequency': lucian}

df = pd.DataFrame(data=d)
plt.plot(df['date'], df['DravenFrequency'], 
         color = 'green', label = 'Draven')
plt.plot(df['date'], df['LucianFrequency'],
         color = 'blue', label = 'Lucian')
plt.legend()
plt.xlabel('date')
plt.ylabel('frequency')
plt.title('Draven and Lucian pick frequency by day')


#%% Plotting on the secondary-y axis


df['LucianGoldEarned'] = gold
fig,ax1 = plt.subplots()
ax2 = ax1.twinx()
ax1.plot(df['date'], df['LucianFrequency'], label = 'frequency', color = 'blue')
ax2.plot(df['date'], df['LucianGoldEarned'], label = 'gold', color = 'black')
ax1.set_ylim([100,500])
ax2.set_ylim([11000,11900])
ax1.set_xlabel('date')
ax1.set_ylabel('frequency')
ax2.set_ylabel('goldEarned')
ax1.legend(loc = "upper left")
ax2.legend(loc = "upper right")
plt.title('Date-frequency and date-gold relationship')

