import pandas as pd
import os

#%% Program set up
# This finds the file path of the parent working directory and stores it in wk_dir
wk_dir = os.path.abspath('..') 

# Reads the match_player.csv and stores it in a DataFrame
df = pd.read_csv(wk_dir+'/Data/match_player_basic.csv')


#%% Section 1: Pandas DataFrame

#Some useful commands to get familiar with a new dataset
print('The first 5 rows: \n\n' , df.head() , '\n')
print('The last 5 rows: \n\n' , df.tail() , '\n')
print('Stats summary: \n\n' , df.describe() , '\n')
print('Access the matchId column: \n\n' , df['matchId'] , '\n')
print('Frequency table for champion column: \n\n' , 
      df['champion'].value_counts().head(10) ,'\n')
print('The resulting table after sorting by matchId: \n\n' ,
      df.sort_values(by='matchId').head(10), '\n')

#%% Section 2: Operations on variable

# The syntax to create a new column
df['killsParticipation'] = df['kills'] + df['assists']

# Measurement of whether a player dies a lot
df['over5Deaths'] = (df['deaths'] > 5).astype(int)

# Apply a lambda function
df['over5Deaths'] = df['deaths'].apply(lambda x: int(x > 5))

#%% Section 3: Subset DataFrame

rows_to_keep = df['champion'] == 'Teemo' # a Series of Booleans
cols_to_keep = ['kills','deaths','assists'] # a list
my_subset = df.loc[rows_to_keep,cols_to_keep]

# An alternative way
my_subset=df.loc[df['champion']=='Teemo',['kills','deaths','assists']]

''' Start the exercise in a new script '''